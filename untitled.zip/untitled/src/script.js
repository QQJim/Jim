<script src="https://www.gstatic.com/firebasejs/9.6.1/firebase-app.js"></script>
<script src="https://www.gstatic.com/firebasejs/9.6.1/firebase-firestore.js"></script>
const firebaseConfig = {
    apiKey: "AIzaSyB_r4w3pb1ZIO8YUCA9Yl9IITSHZi3cCiI",
    authDomain: "class-6bb0b.firebaseapp.com",
    projectId: "class-6bb0b",
    storageBucket: "class-6bb0b.appspot.com",
    messagingSenderId: "709913685558",
    appId: "1:709913685558:web:925486cd1b5b9f99527297",
};
firebase.initializeApp(firebaseConfig);
const db = firebase.firestore();
